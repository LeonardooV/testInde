<?php

?>
<title>Bienvenue dans l'interface pour l'inde</title>

<!-- Pour mettre des styles-->
<link href="Home_style.css" rel="stylesheet">

<h1>Bienvenue dans l'interface pour l'inde</h1>

<nav>
    <ul>
        <li><a href="informations.php">S'informer maintenant</a></li>

</nav>


