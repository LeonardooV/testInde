<?php
$servername = "db";
$username = "root";
$password = "root";
$dbname = "db_inde";
$port = "3306";

$db = new mysqli($servername, $username, $password, $dbname);
